import cv2
import numpy as np

def solution(audio_path):
    ############################
    ############################

    ############################
    ############################
    ## comment the line below before submitting else your code wont be executed##
    # pass
    class_name = 'fake'
    return class_name
